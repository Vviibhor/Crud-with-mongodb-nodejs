const mongoose = require('mongoose');
const Schema = mongoose.Schema;

let BookSchema = new Schema({
    name: {type: String},
    author: {type: String},
});


// Export the model
module.exports = mongoose.model('Book', BookSchema);