// const uuidv4 = require('uuid/v4');
const Book = require('../models/model');
const { GraphQLNonNull, GraphQLObjectType } = require('graphql');

const {
    BookType,
    BookCreateType,
    BookDeleteType,
    BookUpdateType
} = require('./types.js');



const BookMutationType = new GraphQLObjectType({
    name: 'BookMutationType',
    description: 'Mutations for BookType',
    fields: {
        createBook: {
            type: BookType,
            args: {
                input: { type: new GraphQLNonNull(BookCreateType) }
            },
            resolve: (source, { input }) => {
                const book = new Book({
                    name :input.name||"Untitled",
                    author: input.author||"who Knows"
                });
                book.save();
                return book;
            }
        },
        updateBook:{
            type:BookType,
            args:{
                input:{type: new GraphQLNonNull(BookUpdateType)}
            },
            resolve:(source,{input}) =>{
                if(!input.id){
                    return "id cannot be empty";
                }

                Book.findByIdAndUpdate(input.id,{
                    name: input.name || "still Untitled ",
                    author: input.author
                }, {new: true}).then(book =>{
                    if(!book) {
                        return "Not found with id "+input.id;
                    }
                });
                return input;

            }
        },

        deleteBook:{
            type:BookType,
            args:{
                input:{type:new GraphQLNonNull(BookDeleteType)}
            },
            resolve:(source,{input}) => {
                if(!input.id){
                    return "id cannot be empty";
                }

                Book.findByIdAndDelete(input.id).then(book =>{
                    if(!book){
                        return "no book with id "+input.id;
                    }
                });

                return input;
            }
        }
    }
});

module.exports = BookMutationType;