const { GraphQLList, GraphQLObjectType } = require('graphql');

const { BookType } = require('./types.js');

const Book = require('../models/model');
const BookQueryType = new GraphQLObjectType({
    name: 'BookQueryType',
    description: 'Query Schema for BookType',
    fields: {
        books: {
            type: new GraphQLList(BookType),
            resolve: () => Book.find()
            
        }
    }
});

module.exports = BookQueryType;