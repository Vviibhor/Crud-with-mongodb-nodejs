const express = require('express');
const graphqlHTTP = require('express-graphql');
const schema = require('./src/graphql/schema.js');

const PORT = process.env.PORT || 3000;
const app = express();
app.use('/', graphqlHTTP({
    schema: schema,
    graphiql: true
}));

const url ='mongodb://localhost:27017/books';
const mongoose = require('mongoose');

mongoose.Promise = global.Promise;
mongoose.connect(url, {
  useNewUrlParser: true,useFindAndModify: false
}).then(() => {
  console.log("Successfully connected to the database");    
}).catch(err => {
  console.log('Could not connect to the database. Exiting now...', err);
  process.exit();
});





app.listen(PORT);
console.log('GraphQL API Server up and running at localhost:' + PORT);